<?php
//MARC JORNET BOEIRA Creem les variables per a la connexió.
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'pt02_marc_jornet');
?>