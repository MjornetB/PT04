<!DOCTYPE html>
<!-- Marc Jornet Boeira -->
<html lang="en">
<!-- Ficher principal HTML -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show User</title>
    <link rel="stylesheet" type="text/css" href="../mainActions_Pt02.css">
</head>

<body>
    <!-- Formulari visible -->
    <form id="form" action="../Controladors/showController.php" method="POST">
        <input type="submit" name="submit" value="Muestra los usuarios"></input>
    </form>
    <a href="../index.php"><button>Vuelve al menu inicio</button></a><br>

</body>

</html>