<!DOCTYPE html>
<!-- Marc Jornet Boeira -->
<html lang="en">
<!-- Ficher principal HTML -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu principal</title>
    <link rel="stylesheet" type="text/css" href="principalMenu_Pt02.css">

</head>

<body>
    <div>
    <a href="Vistes/insert.php"><button class="BotoMenu">Crea un usuario</button></a><br>
    <a href="Vistes/modify.php"><button class="BotoMenu">Modifica un usuario</button></a><br>
    <a href="Vistes/delete.php"><button class="BotoMenu">Borra un usuario</button></a><br>
    <a href="Vistes/show.php"><button class="BotoMenu">Mostrar los usuarios</button></a><br>
    </div>
</body>

</html>